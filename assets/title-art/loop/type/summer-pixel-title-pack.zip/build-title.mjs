import fs from 'node:fs';
import {fileURLToPath}from'node:url';
const root=fileURLToPath(new URL('../../',import.meta.url));
const dir=fileURLToPath(new URL('./',import.meta.url));
const raw=fs.readFileSync(dir+'source/gb24st.bdf','utf8');
const decoder=new TextDecoder('gb18030'),glyphs=new Map();
for(const block of raw.split('STARTCHAR ').slice(1)){
  const encoding=Number(block.match(/ENCODING (\d+)/)[1]);
  const character=decoder.decode(Uint8Array.from([(encoding>>8)+128,(encoding&255)+128]));
  const rows=block.split('BITMAP\n')[1].split('\nENDCHAR')[0].trim().split('\n');
  glyphs.set(character,rows);
}
const text=process.argv[2]??'四季终焉';
const parts=[],records={};
for(const[c,ch]of[...text].entries()){
  const rows=glyphs.get(ch);if(!rows)throw Error(`Missing ${ch}`);records[ch]=rows;
  for(let y=0;y<24;y++){
    const bits=parseInt(rows[y],16);let start=-1;
    for(let x=0;x<=24;x++){
      if(x<24&&(bits&(1<<(23-x)))){if(start<0)start=x}
      else if(start>=0){parts.push(`M${4+c*28+start} ${2+y}h${x-start}v1h-${x-start}z`);start=-1}
    }
  }
}
const width=text.length*28+4,path=parts.join('');
const notice=fs.readFileSync(dir+'ISAS-LICENSE.txt','utf8');
const svg=`<!-- ${notice} -->\n<svg xmlns="http://www.w3.org/2000/svg" width="${width*5}" height="150" viewBox="0 0 ${width} 30" shape-rendering="crispEdges"><title>${text}</title><defs><linearGradient id="salt" x2="0" y2="1"><stop stop-color="#fffdf2"/><stop offset=".68" stop-color="#f8f9ed"/><stop offset="1" stop-color="#dcefe7"/></linearGradient><path id="letters" d="${path}"/></defs><use href="#letters" transform="translate(0 1)" fill="#427c88" opacity=".2"/><use href="#letters" fill="none" stroke="#578594" stroke-opacity=".32" stroke-width=".5"/><use href="#letters" fill="url(#salt)"/></svg>\n`;
fs.writeFileSync(dir+'summer-title.svg',svg);
fs.writeFileSync(dir+'summer-title-glyphs.json',JSON.stringify({text,font:'ISAS Song 24px',source:'https://gitlab.freedesktop.org/xorg/font/isas-misc',archive:'https://xorg.freedesktop.org/archive/individual/font/font-isas-misc-1.0.4.tar.xz',license:'ISAS-LICENSE.txt',grid:24,glyphs:records},null,2)+'\n');
console.log({text,width,height:30,glyphs:glyphs.size});
